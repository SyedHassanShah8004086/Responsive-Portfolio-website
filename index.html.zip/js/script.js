$(function(){
    $('#menu').slicknav({
        label:"",
        brand:"Shah Saab"
    });
});


$(document).ready(function() {
    $(".skitter-large").skitter({
        dots:false,
        navigation:true,
        theme:'clean'
    });
  });

*/
  $(document).ready(function(){
    $(".owl-carousel").owlCarousel({
        loop:true,
        margin:100,
        responsiveClass:true,
        responsive:{
            0:{
                items:1,
                nav:false
            },
            600:{
                items:3,
                nav:false
            },
            1000:{
                items:5,
                nav:false,
                loop:false
            }
        }
    });
  });

  $(document).ready(function(){
$(".progress-bar-html").animate({"width":"90%"},1000,function(){
        $(".progress-bar-css2").animate({"width":"85%"},1000,function(){
        $(".progress-bar-css3").animate({"width":"90%"},1000,function(){
$(".progress-bar-java-script").animate({"width":"70%"},1000,function(){
 $(".progress-bar-jquery").animate({"width":"75%"},1000,function(){
$(".progress-bar-c_plus").animate({"width":"85%"},1000);
 });   
});
        });
        });
    });
  });